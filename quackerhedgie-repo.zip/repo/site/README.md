# QuackerHedgie Community

A small PHP web-tech community board built around the QuackerHedgie mascot —
members post PHP/JS/CSS/dev tips, discuss them in comments, and react with
hedgehog stickers cropped from the original sticker sheet.

## Requirements
- PHP 8.0+ with the `pdo_pgsql` extension
- A PostgreSQL server (9.6+) reachable from PHP
- No other dependencies — no Composer

## 1. Create the database
```sql
CREATE DATABASE quackerhedgie;
```
Tables are created automatically on first request — no migration step needed.

## 2. Configure the connection
Set these environment variables (defaults shown), or edit them directly at
the top of `config.php`:

| Variable  | Default          |
|-----------|------------------|
| `DB_HOST` | `127.0.0.1`      |
| `DB_PORT` | `5432`           |
| `DB_NAME` | `quackerhedgie`  |
| `DB_USER` | `postgres`       |
| `DB_PASS` | `postgres`       |

Example:
```bash
export DB_HOST=localhost
export DB_NAME=quackerhedgie
export DB_USER=quacker
export DB_PASS=changeme
```

### Email verification (SMTP)

Registration now requires clicking a verification link before login works.
Configure how that email gets sent:

| Variable        | Default                          | Notes |
|-----------------|-----------------------------------|-------|
| `APP_URL`       | `http://localhost:8000`          | Used to build the link inside the email — set this to your real domain in production |
| `MAIL_FROM`     | `no-reply@quackerhedgie.local`   | From address |
| `MAIL_FROM_NAME`| `QuackerHedgie Community`        | From display name |
| `SMTP_HOST`     | *(unset)*                         | If set, email is sent via authenticated SMTP. If unset, PHP's built-in `mail()` is used instead (requires a local sendmail/postfix setup) |
| `SMTP_PORT`     | `587`                             | `587` for STARTTLS, `465` for implicit TLS |
| `SMTP_USER` / `SMTP_PASS` | *(unset)*               | SMTP auth credentials |
| `SMTP_SECURE`   | `tls`                             | `tls` (STARTTLS) or `ssl` (implicit TLS) |

Example using Gmail SMTP (with an app password) or any transactional
provider (SendGrid, Mailgun, Postmark, SES's SMTP interface, etc.):
```bash
export APP_URL=https://community.example.com
export SMTP_HOST=smtp.sendgrid.net
export SMTP_PORT=587
export SMTP_USER=apikey
export SMTP_PASS=your_sendgrid_api_key
export SMTP_SECURE=tls
```
No dependency is needed for this — `includes/mail.php` speaks raw SMTP
directly over a socket. If `SMTP_HOST` is left unset, the app falls back to
PHP's `mail()`, which is fine for quick local testing but unreliable for
real delivery.

### Migrating an existing database
If you already created the database with the previous schema (no email
column), run this once before upgrading:
```sql
ALTER TABLE users ADD COLUMN email TEXT UNIQUE NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN email_verified_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN verification_token TEXT;
ALTER TABLE users ADD COLUMN verification_sent_at TIMESTAMPTZ;
-- existing accounts should be considered pre-verified so they aren't locked out:
UPDATE users SET email_verified_at = NOW() WHERE email_verified_at IS NULL;
```
A brand-new database created after this update doesn't need any of this —
the schema above is already included in the auto-bootstrap.

## 3. Run it locally
```bash
cd site
php -S localhost:8000
```
Open http://localhost:8000. On first request the schema is created and
seeded with a welcome post from the bot account:
- username: `QuackerHedgie`
- password: `hedgie-bot`

## Deploy on a real web server
Point your document root at the `site/` folder, set the `DB_*` environment
variables for the PHP process (Apache `SetEnv`, PHP-FPM pool `env[]`, etc.),
and make sure the app's PostgreSQL user can create tables in the target
database (only needed once, for the auto-bootstrap).

## Structure
```
site/
  config.php            PostgreSQL connection + schema bootstrap + helpers
  index.php             Feed of tips, filterable by category
  post.php              Single tip: full text, reactions, comments
  new_post.php          Post a new tip (requires login)
  register.php / login.php / logout.php
  verify.php / verify_notice.php / resend_verification.php   Email verification flow
  react.php / comment.php   Form-post handlers (no JS required)
  includes/             Shared header/footer
  assets/style.css      Neon-blue tech visual theme
  assets/images/*.png   12 hedgehog stickers cropped from the sticker sheet,
                         used as user avatars and post reactions
```

## Notes
- Passwords are hashed with `password_hash()`; sessions use PHP's built-in
  session handling.
- All user input is escaped with `htmlspecialchars()` and all SQL uses
  prepared statements (PDO, `pgsql` driver).
- Inserts that need the new row's id use PostgreSQL's `RETURNING id` rather
  than `lastInsertId()`.
- Reactions are a simple toggle (click again to un-react), one per user per
  type per post, enforced with a DB unique constraint.
- New accounts can't log in until they click the emailed verification link
  (valid 24 hours); `resend_verification.php` always replies with the same
  generic message so it can't be used to check which emails are registered.
