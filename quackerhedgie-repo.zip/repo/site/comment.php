<?php
require_once __DIR__ . '/config.php';
$me = require_login();

$postId = (int)($_POST['post_id'] ?? 0);
$body = trim($_POST['body'] ?? '');

if ($postId && $body !== '') {
    $stmt = db()->prepare('INSERT INTO comments (post_id, user_id, body) VALUES (:p, :u, :b)');
    $stmt->execute([':p' => $postId, ':u' => $me['id'], ':b' => $body]);
}

header('Location: post.php?id=' . $postId . '#comments');
exit;
