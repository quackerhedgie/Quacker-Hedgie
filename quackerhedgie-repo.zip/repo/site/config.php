<?php
/**
 * QuackerHedgie Community — config & DB bootstrap
 * Uses PostgreSQL via PDO (pdo_pgsql).
 *
 * Connection settings can be overridden with environment variables:
 *   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASS
 * or by editing the defaults below directly.
 */
declare(strict_types=1);
session_start();

define('APP_NAME', 'QuackerHedgie Community');
define('APP_TAGLINE', 'Quacker Hedgie: Tech Everyday!');
require_once __DIR__ . '/includes/mail.php';

define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '5432');
define('DB_NAME', getenv('DB_NAME') ?: 'quackerhedgie');
define('DB_USER', getenv('DB_USER') ?: 'postgres');
define('DB_PASS', getenv('DB_PASS') ?: 'postgres');

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf('pgsql:host=%s;port=%s;dbname=%s', DB_HOST, DB_PORT, DB_NAME);
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);

        $exists = $pdo->query("SELECT to_regclass('public.users')")->fetchColumn();
        if ($exists === null) {
            bootstrap_schema($pdo);
        }
    }
    return $pdo;
}

function bootstrap_schema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE users (
            id SERIAL PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            avatar TEXT DEFAULT 'wave',
            email_verified_at TIMESTAMPTZ,
            verification_token TEXT,
            verification_sent_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE posts (
            id SERIAL PRIMARY KEY,
            user_id INTEGER NOT NULL REFERENCES users(id),
            category TEXT NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE comments (
            id SERIAL PRIMARY KEY,
            post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id),
            body TEXT NOT NULL,
            created_at TIMESTAMPTZ DEFAULT NOW()
        );

        CREATE TABLE reactions (
            id SERIAL PRIMARY KEY,
            post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
            user_id INTEGER NOT NULL REFERENCES users(id),
            type TEXT NOT NULL,
            UNIQUE(post_id, user_id, type)
        );
    ");

    // Seed with a welcome post from the mascot itself (pre-verified system account)
    $stmt = $pdo->prepare("
        INSERT INTO users (username, email, password_hash, avatar, email_verified_at)
        VALUES ('QuackerHedgie', 'bot@quackerhedgie.local', :hash, 'cool', NOW())
        RETURNING id
    ");
    $stmt->execute([':hash' => password_hash('hedgie-bot', PASSWORD_DEFAULT)]);
    $botId = $stmt->fetchColumn();

    $stmt = $pdo->prepare("INSERT INTO posts (user_id, category, title, body) VALUES (:uid, 'Announcement', :title, :body)");
    $stmt->execute([
        ':uid' => $botId,
        ':title' => 'Welcome to the burrow! 🦔',
        ':body' => "This is the community space for " . APP_NAME . ". Share PHP, JS, CSS and dev-life tips, ask questions, and react with your favorite hedgehog. Quacker Hedgie: Tech Everyday!"
    ]);
}

/** Reaction types mapped to the cropped sticker files in assets/images */
const REACTIONS = [
    'love'   => 'Love it',
    'party'  => 'Nice one!',
    'fire'   => 'Fire tip',
    'think'  => 'Hmm, interesting',
    'cool'   => 'Cool',
    'cookie' => 'Sweet',
];

function current_user(): ?array
{
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    static $cache = null;
    if ($cache === null) {
        $stmt = db()->prepare('SELECT id, username, avatar FROM users WHERE id = :id');
        $stmt->execute([':id' => $_SESSION['user_id']]);
        $cache = $stmt->fetch() ?: null;
    }
    return $cache;
}

function require_login(): array
{
    $u = current_user();
    if (!$u) {
        header('Location: login.php');
        exit;
    }
    return $u;
}

function e(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function time_ago(string $datetime): string
{
    $diff = time() - strtotime($datetime);
    if ($diff < 60) return 'just now';
    if ($diff < 3600) return floor($diff / 60) . 'm ago';
    if ($diff < 86400) return floor($diff / 3600) . 'h ago';
    return floor($diff / 86400) . 'd ago';
}
