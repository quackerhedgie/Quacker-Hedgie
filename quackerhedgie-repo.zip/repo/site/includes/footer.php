</main>
<footer class="footer">
    <div class="wrap">
        <img src="assets/images/sleep.png" class="avatar-sm" alt="">
        <span><?= e(APP_NAME) ?> — built with PHP &amp; a very caffeinated hedgehog.</span>
    </div>
</footer>
</body>
</html>
