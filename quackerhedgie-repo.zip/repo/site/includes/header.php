<?php
require_once __DIR__ . '/../config.php';
$me = current_user();
?>
<!DOCTYPE html>
<html lang="ko">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? e($pageTitle) . ' · ' : '' ?><?= e(APP_NAME) ?></title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
    <div class="wrap topbar-inner">
        <a class="brand" href="index.php">
            <img src="assets/images/wave.png" alt="" class="brand-icon">
            <span>
                <span class="brand-name"><?= e(APP_NAME) ?></span>
                <span class="brand-tagline"><?= e(APP_TAGLINE) ?></span>
            </span>
        </a>
        <nav class="nav">
            <a href="index.php">Feed</a>
            <?php if ($me): ?>
                <a href="new_post.php" class="btn-ghost">+ New Tip</a>
                <span class="me">
                    <img src="assets/images/<?= e($me['avatar']) ?>.png" class="avatar-sm" alt="">
                    <?= e($me['username']) ?>
                </span>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php" class="btn-ghost">Join</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
<main class="wrap main">
<?php if (!empty($_SESSION['flash'])): ?>
    <div class="flash"><?= e($_SESSION['flash']) ?></div>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>
