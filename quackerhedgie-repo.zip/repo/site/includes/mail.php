<?php
/**
 * Minimal mail sender — no Composer/PHPMailer dependency.
 *
 * If SMTP_HOST is set, sends via a raw authenticated SMTP connection
 * (supports STARTTLS on 587 or implicit TLS on 465). Otherwise falls
 * back to PHP's built-in mail() function.
 *
 * Configure via environment variables:
 *   MAIL_FROM        e.g. no-reply@yourdomain.com
 *   MAIL_FROM_NAME    e.g. "QuackerHedgie Community"
 *   APP_URL           e.g. https://yourdomain.com  (used to build verification links)
 *   SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_SECURE (tls|ssl)
 */
declare(strict_types=1);

define('MAIL_FROM', getenv('MAIL_FROM') ?: 'no-reply@quackerhedgie.local');
define('MAIL_FROM_NAME', getenv('MAIL_FROM_NAME') ?: APP_NAME);
define('APP_URL', rtrim(getenv('APP_URL') ?: 'http://localhost:8000', '/'));

/**
 * Send an HTML email. Returns true on (apparent) success.
 */
function send_mail(string $to, string $subject, string $htmlBody): bool
{
    $smtpHost = getenv('SMTP_HOST');
    if ($smtpHost) {
        try {
            smtp_send($to, $subject, $htmlBody);
            return true;
        } catch (\Throwable $e) {
            error_log('SMTP send failed: ' . $e->getMessage());
            return false;
        }
    }

    // Fallback: PHP's mail() — requires a configured local MTA (sendmail/postfix).
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";
    $headers .= 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . ">\r\n";
    return mail($to, $subject, $htmlBody, $headers);
}

/**
 * Very small authenticated SMTP client. Enough for transactional email
 * (verification links) — not a full mail library.
 */
function smtp_send(string $to, string $subject, string $htmlBody): void
{
    $host = getenv('SMTP_HOST');
    $port = (int)(getenv('SMTP_PORT') ?: 587);
    $user = getenv('SMTP_USER');
    $pass = getenv('SMTP_PASS');
    $secure = getenv('SMTP_SECURE') ?: 'tls'; // 'tls' (STARTTLS on 587) or 'ssl' (implicit TLS on 465)

    $transport = $secure === 'ssl' ? 'ssl://' . $host : $host;
    $sock = @fsockopen($transport, $port, $errno, $errstr, 10);
    if (!$sock) {
        throw new \RuntimeException("Could not connect to SMTP host: $errstr ($errno)");
    }

    $expect = function (int $wantCode) use ($sock) {
        $line = '';
        do {
            $line = fgets($sock, 515);
            if ($line === false) {
                throw new \RuntimeException('SMTP connection closed unexpectedly');
            }
        } while (isset($line[3]) && $line[3] === '-'); // multi-line response
        $code = (int)substr($line, 0, 3);
        if ($code !== $wantCode) {
            throw new \RuntimeException("SMTP error: expected $wantCode, got: $line");
        }
    };
    $send = function (string $cmd) use ($sock) {
        fwrite($sock, $cmd . "\r\n");
    };

    $expect(220);
    $send('EHLO ' . (parse_url(APP_URL, PHP_URL_HOST) ?: 'localhost'));
    $expect(250);

    if ($secure === 'tls') {
        $send('STARTTLS');
        $expect(220);
        stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
        $send('EHLO ' . (parse_url(APP_URL, PHP_URL_HOST) ?: 'localhost'));
        $expect(250);
    }

    if ($user && $pass) {
        $send('AUTH LOGIN');
        $expect(334);
        $send(base64_encode($user));
        $expect(334);
        $send(base64_encode($pass));
        $expect(235);
    }

    $send('MAIL FROM:<' . MAIL_FROM . '>');
    $expect(250);
    $send('RCPT TO:<' . $to . '>');
    $expect(250);
    $send('DATA');
    $expect(354);

    $headers = [];
    $headers[] = 'From: ' . MAIL_FROM_NAME . ' <' . MAIL_FROM . '>';
    $headers[] = 'To: <' . $to . '>';
    $headers[] = 'Subject: ' . $subject;
    $headers[] = 'MIME-Version: 1.0';
    $headers[] = 'Content-Type: text/html; charset=UTF-8';
    $message = implode("\r\n", $headers) . "\r\n\r\n" . $htmlBody . "\r\n.";
    $send($message);
    $expect(250);

    $send('QUIT');
    fclose($sock);
}

/** Generate a URL-safe random verification token. */
function generate_token(): string
{
    return bin2hex(random_bytes(32));
}

/** Build and send the "verify your email" message. */
function send_verification_email(string $email, string $username, string $token): bool
{
    $link = APP_URL . '/verify.php?token=' . $token;
    $html = "
        <div style='font-family:sans-serif;max-width:480px;margin:0 auto'>
            <h2>🦔 " . e(APP_NAME) . "</h2>
            <p>Hi {$username},</p>
            <p>Thanks for joining the burrow! Please confirm your email address to activate your account:</p>
            <p><a href='{$link}' style='background:#00e5ff;color:#04121e;padding:10px 20px;border-radius:999px;text-decoration:none;font-weight:bold;display:inline-block'>Verify my email</a></p>
            <p style='color:#888;font-size:0.85em'>This link expires in 24 hours. If the button doesn't work, copy this link:<br>{$link}</p>
        </div>
    ";
    return send_mail($email, 'Confirm your email — ' . APP_NAME, $html);
}
