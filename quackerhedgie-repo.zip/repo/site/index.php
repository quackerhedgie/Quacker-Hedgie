<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Feed';

$category = $_GET['category'] ?? '';
$categories = db()->query("SELECT DISTINCT category FROM posts ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);

$sql = "
    SELECT p.*, u.username, u.avatar,
        (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comment_count
    FROM posts p
    JOIN users u ON u.id = p.user_id
";
$params = [];
if ($category !== '') {
    $sql .= " WHERE p.category = :cat";
    $params[':cat'] = $category;
}
$sql .= " ORDER BY p.created_at DESC";
$stmt = db()->prepare($sql);
$stmt->execute($params);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// reaction counts for all shown posts
$reactionCounts = [];
if ($posts) {
    $ids = array_column($posts, 'id');
    $in = implode(',', array_fill(0, count($ids), '?'));
    $rstmt = db()->prepare("SELECT post_id, type, COUNT(*) AS n FROM reactions WHERE post_id IN ($in) GROUP BY post_id, type");
    $rstmt->execute($ids);
    foreach ($rstmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $reactionCounts[$row['post_id']][$row['type']] = (int)$row['n'];
    }
}

require __DIR__ . '/includes/header.php';
?>

<div class="feed-layout">
    <aside class="sidebar">
        <h3>Categories</h3>
        <ul class="cat-list">
            <li><a class="<?= $category === '' ? 'active' : '' ?>" href="index.php">All tips</a></li>
            <?php foreach ($categories as $c): ?>
                <li><a class="<?= $category === $c ? 'active' : '' ?>" href="index.php?category=<?= urlencode($c) ?>"><?= e($c) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <div class="mascot-card">
            <img src="assets/images/party.png" alt="">
            <p>Got a tip? Post it and the burrow will react.</p>
        </div>
    </aside>

    <section class="feed">
        <?php if (!$posts): ?>
            <div class="empty-state">
                <img src="assets/images/think.png" alt="">
                <p>No tips here yet. Be the first!</p>
            </div>
        <?php endif; ?>

        <?php foreach ($posts as $p): ?>
            <article class="card post-card">
                <div class="post-head">
                    <img src="assets/images/<?= e($p['avatar']) ?>.png" class="avatar" alt="">
                    <div>
                        <a class="post-title" href="post.php?id=<?= $p['id'] ?>"><?= e($p['title']) ?></a>
                        <div class="meta">
                            <span class="tag"><?= e($p['category']) ?></span>
                            by <strong><?= e($p['username']) ?></strong> · <?= time_ago($p['created_at']) ?>
                        </div>
                    </div>
                </div>
                <p class="post-body"><?= nl2br(e(mb_strimwidth($p['body'], 0, 220, '…'))) ?></p>
                <div class="post-foot">
                    <div class="reactions">
                        <?php foreach (REACTIONS as $type => $label): ?>
                            <span class="reaction-pill" title="<?= e($label) ?>">
                                <img src="assets/images/<?= $type ?>.png" alt="<?= e($label) ?>">
                                <?= $reactionCounts[$p['id']][$type] ?? 0 ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                    <a class="comment-link" href="post.php?id=<?= $p['id'] ?>#comments">💬 <?= (int)$p['comment_count'] ?></a>
                </div>
            </article>
        <?php endforeach; ?>
    </section>
</div>

<?php require __DIR__ . '/includes/footer.php'; ?>
