<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Login';
$error = '';
$unverifiedEmail = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = db()->prepare('SELECT * FROM users WHERE username = :u');
    $stmt->execute([':u' => $username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password_hash'])) {
        if ($user['email_verified_at'] === null) {
            $error = 'Please verify your email before logging in.';
            $unverifiedEmail = $user['email'];
        } else {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['flash'] = "Welcome back, {$user['username']}!";
            header('Location: index.php');
            exit;
        }
    } else {
        $error = 'Invalid username or password.';
    }
}

require __DIR__ . '/includes/header.php';
?>
<div class="card auth-card">
    <h2>Log in</h2>
    <?php if ($error): ?>
        <p class="error"><?= e($error) ?></p>
        <?php if ($unverifiedEmail): ?>
            <form method="post" action="resend_verification.php" class="inline-resend">
                <input type="hidden" name="email" value="<?= e($unverifiedEmail) ?>">
                <button type="submit" class="btn-ghost">Resend verification email</button>
            </form>
        <?php endif; ?>
    <?php endif; ?>
    <form method="post">
        <label>Username
            <input type="text" name="username" required value="<?= e($_POST['username'] ?? '') ?>">
        </label>
        <label>Password
            <input type="password" name="password" required>
        </label>
        <button type="submit" class="btn-primary">Log in</button>
    </form>
    <p class="switch-auth">New here? <a href="register.php">Join the community</a></p>
    <p class="hint">Demo bot account: <code>QuackerHedgie</code> / <code>hedgie-bot</code></p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
