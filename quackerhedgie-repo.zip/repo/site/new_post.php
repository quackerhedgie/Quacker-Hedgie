<?php
require_once __DIR__ . '/config.php';
$me = require_login();
$pageTitle = 'New Tip';
$error = '';

$suggestedCategories = ['PHP', 'JavaScript', 'CSS', 'DevOps', 'Databases', 'Career', 'Tooling', 'Announcement'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $body = trim($_POST['body'] ?? '');

    if ($title === '' || $category === '' || $body === '') {
        $error = 'All fields are required.';
    } else {
        $stmt = db()->prepare('INSERT INTO posts (user_id, category, title, body) VALUES (:u, :c, :t, :b) RETURNING id');
        $stmt->execute([':u' => $me['id'], ':c' => $category, ':t' => $title, ':b' => $body]);
        $newId = $stmt->fetchColumn();
        $_SESSION['flash'] = 'Your tip is live!';
        header('Location: post.php?id=' . $newId);
        exit;
    }
}

require __DIR__ . '/includes/header.php';
?>
<div class="card">
    <h2><img src="assets/images/party.png" class="avatar-sm" alt=""> Share a tech tip</h2>
    <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
    <form method="post">
        <label>Title
            <input type="text" name="title" required maxlength="120" value="<?= e($_POST['title'] ?? '') ?>">
        </label>
        <label>Category
            <input list="cat-suggestions" name="category" required maxlength="30" value="<?= e($_POST['category'] ?? '') ?>">
            <datalist id="cat-suggestions">
                <?php foreach ($suggestedCategories as $c): ?>
                    <option value="<?= e($c) ?>">
                <?php endforeach; ?>
            </datalist>
        </label>
        <label>Details
            <textarea name="body" rows="8" required><?= e($_POST['body'] ?? '') ?></textarea>
        </label>
        <button type="submit" class="btn-primary">Post tip</button>
    </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
