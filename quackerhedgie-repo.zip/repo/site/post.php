<?php
require_once __DIR__ . '/config.php';
$me = current_user();

$id = (int)($_GET['id'] ?? 0);
$stmt = db()->prepare("
    SELECT p.*, u.username, u.avatar
    FROM posts p JOIN users u ON u.id = p.user_id
    WHERE p.id = :id
");
$stmt->execute([':id' => $id]);
$post = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    http_response_code(404);
    $pageTitle = 'Not found';
    require __DIR__ . '/includes/header.php';
    echo '<div class="card empty-state"><img src="assets/images/shock.png" alt=""><p>That tip wandered off into the bushes.</p></div>';
    require __DIR__ . '/includes/footer.php';
    exit;
}
$pageTitle = $post['title'];

// reaction counts + whether current user already reacted with each type
$rstmt = db()->prepare('SELECT type, COUNT(*) AS n FROM reactions WHERE post_id = :id GROUP BY type');
$rstmt->execute([':id' => $id]);
$counts = array_column($rstmt->fetchAll(PDO::FETCH_ASSOC), 'n', 'type');

$mine = [];
if ($me) {
    $mstmt = db()->prepare('SELECT type FROM reactions WHERE post_id = :id AND user_id = :uid');
    $mstmt->execute([':id' => $id, ':uid' => $me['id']]);
    $mine = $mstmt->fetchAll(PDO::FETCH_COLUMN);
}

$cstmt = db()->prepare("
    SELECT c.*, u.username, u.avatar
    FROM comments c JOIN users u ON u.id = c.user_id
    WHERE c.post_id = :id ORDER BY c.created_at ASC
");
$cstmt->execute([':id' => $id]);
$comments = $cstmt->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/includes/header.php';
?>

<article class="card post-card post-full">
    <div class="post-head">
        <img src="assets/images/<?= e($post['avatar']) ?>.png" class="avatar" alt="">
        <div>
            <h2 class="post-title"><?= e($post['title']) ?></h2>
            <div class="meta">
                <span class="tag"><?= e($post['category']) ?></span>
                by <strong><?= e($post['username']) ?></strong> · <?= time_ago($post['created_at']) ?>
            </div>
        </div>
    </div>
    <p class="post-body"><?= nl2br(e($post['body'])) ?></p>

    <div class="post-foot">
        <div class="reactions">
            <?php foreach (REACTIONS as $type => $label): ?>
                <?php if ($me): ?>
                    <form method="post" action="react.php" class="reaction-form">
                        <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                        <input type="hidden" name="type" value="<?= $type ?>">
                        <button type="submit" class="reaction-pill <?= in_array($type, $mine, true) ? 'active' : '' ?>" title="<?= e($label) ?>">
                            <img src="assets/images/<?= $type ?>.png" alt="<?= e($label) ?>">
                            <?= $counts[$type] ?? 0 ?>
                        </button>
                    </form>
                <?php else: ?>
                    <span class="reaction-pill" title="Log in to react">
                        <img src="assets/images/<?= $type ?>.png" alt="<?= e($label) ?>">
                        <?= $counts[$type] ?? 0 ?>
                    </span>
                <?php endif; ?>
            <?php endforeach; ?>
        </div>
    </div>
</article>

<section class="card" id="comments">
    <h3><img src="assets/images/think.png" class="avatar-sm" alt=""> Discussion (<?= count($comments) ?>)</h3>

    <?php foreach ($comments as $c): ?>
        <div class="comment">
            <img src="assets/images/<?= e($c['avatar']) ?>.png" class="avatar-sm" alt="">
            <div>
                <div class="meta"><strong><?= e($c['username']) ?></strong> · <?= time_ago($c['created_at']) ?></div>
                <p><?= nl2br(e($c['body'])) ?></p>
            </div>
        </div>
    <?php endforeach; ?>

    <?php if ($me): ?>
        <form method="post" action="comment.php" class="comment-form">
            <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
            <textarea name="body" rows="3" placeholder="Add to the discussion…" required></textarea>
            <button type="submit" class="btn-primary">Reply</button>
        </form>
    <?php else: ?>
        <p class="hint"><a href="login.php">Log in</a> to join the discussion.</p>
    <?php endif; ?>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
