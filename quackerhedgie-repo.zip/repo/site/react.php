<?php
require_once __DIR__ . '/config.php';
$me = require_login();

$postId = (int)($_POST['post_id'] ?? 0);
$type = $_POST['type'] ?? '';

if ($postId && array_key_exists($type, REACTIONS)) {
    $stmt = db()->prepare('SELECT id FROM reactions WHERE post_id = :p AND user_id = :u AND type = :t');
    $stmt->execute([':p' => $postId, ':u' => $me['id'], ':t' => $type]);
    if ($existing = $stmt->fetch()) {
        db()->prepare('DELETE FROM reactions WHERE id = :id')->execute([':id' => $existing['id']]);
    } else {
        db()->prepare('INSERT INTO reactions (post_id, user_id, type) VALUES (:p, :u, :t)')
            ->execute([':p' => $postId, ':u' => $me['id'], ':t' => $type]);
    }
}

header('Location: post.php?id=' . $postId . '#reactions');
exit;
