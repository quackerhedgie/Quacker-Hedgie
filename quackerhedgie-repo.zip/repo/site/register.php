<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Join';
$error = '';

$avatarOptions = ['wave', 'love', 'cool', 'party', 'heart', 'bye'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $avatar = in_array($_POST['avatar'] ?? '', $avatarOptions, true) ? $_POST['avatar'] : 'wave';

    if ($username === '' || $email === '' || $password === '') {
        $error = 'Username, email and password are required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($password) < 4) {
        $error = 'Password must be at least 4 characters.';
    } else {
        $stmt = db()->prepare('SELECT id FROM users WHERE username = :u OR email = :e');
        $stmt->execute([':u' => $username, ':e' => $email]);
        if ($stmt->fetch()) {
            $error = 'That username or email is already registered.';
        } else {
            $token = generate_token();
            $stmt = db()->prepare('
                INSERT INTO users (username, email, password_hash, avatar, verification_token, verification_sent_at)
                VALUES (:u, :e, :p, :a, :t, NOW())
                RETURNING id
            ');
            $stmt->execute([
                ':u' => $username,
                ':e' => $email,
                ':p' => password_hash($password, PASSWORD_DEFAULT),
                ':a' => $avatar,
                ':t' => $token,
            ]);

            send_verification_email($email, $username, $token);

            $_SESSION['flash'] = "Almost there! We've sent a verification link to {$email}.";
            header('Location: verify_notice.php?email=' . urlencode($email));
            exit;
        }
    }
}

require __DIR__ . '/includes/header.php';
?>
<div class="card auth-card">
    <h2>Join the community</h2>
    <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
    <form method="post">
        <label>Username
            <input type="text" name="username" required maxlength="24" value="<?= e($_POST['username'] ?? '') ?>">
        </label>
        <label>Email
            <input type="email" name="email" required maxlength="120" value="<?= e($_POST['email'] ?? '') ?>">
        </label>
        <label>Password
            <input type="password" name="password" required minlength="4">
        </label>
        <label>Pick your hedgehog
            <div class="avatar-picker">
                <?php foreach ($avatarOptions as $a): ?>
                    <label class="avatar-choice">
                        <input type="radio" name="avatar" value="<?= $a ?>" <?= $a === 'wave' ? 'checked' : '' ?>>
                        <img src="assets/images/<?= $a ?>.png" alt="<?= $a ?>">
                    </label>
                <?php endforeach; ?>
            </div>
        </label>
        <button type="submit" class="btn-primary">Create account</button>
    </form>
    <p class="switch-auth">Already a member? <a href="login.php">Log in</a></p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
