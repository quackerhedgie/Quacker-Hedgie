<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Resend verification';

$email = trim($_POST['email'] ?? $_GET['email'] ?? '');

if ($email !== '') {
    $stmt = db()->prepare("
        SELECT * FROM users
        WHERE email = :e AND email_verified_at IS NULL
    ");
    $stmt->execute([':e' => $email]);
    $user = $stmt->fetch();

    if ($user) {
        // Simple rate limit: at most one resend per 60 seconds.
        $sentAt = $user['verification_sent_at'] ? strtotime($user['verification_sent_at']) : 0;
        if (time() - $sentAt > 60) {
            $token = generate_token();
            db()->prepare('UPDATE users SET verification_token = :t, verification_sent_at = NOW() WHERE id = :id')
                ->execute([':t' => $token, ':id' => $user['id']]);
            send_verification_email($email, $user['username'], $token);
        }
    }
}

// Always show the same message, whether or not the email was found/eligible,
// so this endpoint can't be used to check which emails are registered.
$_SESSION['flash'] = "If {$email} needs verifying, a new link is on its way.";
header('Location: verify_notice.php?email=' . urlencode($email));
exit;
