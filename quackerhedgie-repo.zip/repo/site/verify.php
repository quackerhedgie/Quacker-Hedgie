<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Verify email';

$token = $_GET['token'] ?? '';
$user = null;

if ($token !== '') {
    $stmt = db()->prepare("
        SELECT * FROM users
        WHERE verification_token = :t
          AND verification_sent_at > NOW() - INTERVAL '24 hours'
    ");
    $stmt->execute([':t' => $token]);
    $user = $stmt->fetch();
}

if ($user) {
    db()->prepare('UPDATE users SET email_verified_at = NOW(), verification_token = NULL WHERE id = :id')
        ->execute([':id' => $user['id']]);
    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['flash'] = "Email verified — welcome to the burrow, {$user['username']}! 🎉";
    header('Location: index.php');
    exit;
}

require __DIR__ . '/includes/header.php';
?>
<div class="card auth-card" style="text-align:center">
    <img src="assets/images/shock.png" alt="" style="width:80px;margin-bottom:10px">
    <h2>That link isn't valid</h2>
    <p>It may have expired (links last 24 hours) or already been used.</p>
    <form method="post" action="resend_verification.php">
        <label>Enter your email to get a new link
            <input type="email" name="email" required>
        </label>
        <button type="submit" class="btn-primary">Send new link</button>
    </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
