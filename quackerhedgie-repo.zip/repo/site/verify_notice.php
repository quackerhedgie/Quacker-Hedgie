<?php
require_once __DIR__ . '/config.php';
$pageTitle = 'Check your email';
$email = $_GET['email'] ?? '';

require __DIR__ . '/includes/header.php';
?>
<div class="card auth-card" style="text-align:center">
    <img src="assets/images/love.png" alt="" style="width:80px;margin-bottom:10px">
    <h2>Check your inbox!</h2>
    <p>We've sent a verification link to<br><strong><?= e($email) ?></strong></p>
    <p class="hint">Click the link in that email to activate your account. Didn't get it?</p>
    <form method="post" action="resend_verification.php">
        <input type="hidden" name="email" value="<?= e($email) ?>">
        <button type="submit" class="btn-ghost">Resend verification email</button>
    </form>
    <p class="switch-auth"><a href="login.php">Back to login</a></p>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
